package nz.ac.auckland.concert.common;

/*
 * Config stores network properties for the application.
 * 
 */
public class Config {
	// Port number that the Server listens on for accepting connections.
	public static final int SERVER_PORT = 8080;
}
